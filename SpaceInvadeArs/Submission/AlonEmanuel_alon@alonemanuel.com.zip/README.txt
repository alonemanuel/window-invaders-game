Objective:
Control either the top player or the bottom payer in order to hit th other player.
Your shots are being blocked by the neighbors that stick their heads out of the window. Be swift and speedy as they will pop their head back after four seconds.
This is a take off of the classic Space Invaders game, with the obvious change of design, and the game incentive change.

Designers:
Roee Ovadia, Tomer Ben-Yair

Programmer:
Alon Emanuel